import React from 'react';
import ReminderForm from '../components/ReminderForm';

export default function AddReminderScreen() {
  return <ReminderForm />;
}
